#include "ConsoleObserver.h"

void ConsoleObserver::update(const std::string& message) {
    std::cout << message << std::endl;
}

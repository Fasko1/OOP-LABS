#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int countOnesInRange(int a, int b);

#endif // FUNCTIONS_H
